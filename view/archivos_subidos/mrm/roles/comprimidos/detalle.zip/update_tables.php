<?php
require_once(dirname(__FILE__). '/../../../config.php');
require('query.php');
global $DB;

$sql_query2 = 'DELETE FROM {talentospilos_seg_estudiante} ';
   
$result2 = $DB->execute($sql_query2);

$sql_query = 'DELETE FROM {talentospilos_seguimiento} ';
$result = $DB->execute($sql_query);
   

