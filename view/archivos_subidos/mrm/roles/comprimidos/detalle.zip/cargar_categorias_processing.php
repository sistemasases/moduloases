<?php

require_once('query.php');


if(isset($_POST['course'])){

        $cursos = getCategories($_POST['course']);
        
        echo json_encode($cursos);
    }

    
