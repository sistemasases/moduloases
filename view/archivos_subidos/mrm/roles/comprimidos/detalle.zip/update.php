<?php
require_once(dirname(__FILE__). '/../../../config.php');
require('query.php');
    global $DB;
    
    
    //  $sql_query2 = 'DELETE FROM {talentospilos_seg_estudiante} ';
   
    // $result2 = $DB->execute($sql_query2);
    
    // $sql_query = 'DELETE FROM {talentospilos_seguimiento} ';
    //  $result = $DB->execute($sql_query);
   

    // print_r($result);
    // print_r($result2);

    //COMENTADO POR ESTEBAN 20170417
    $record->nombre="individual";
    $record->descripcion = "Riesgo individual";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);
    
    $record->nombre="familiar";
    $record->descripcion = "Riesgo familiar";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);
    
    $record->nombre="academico";
    $record->descripcion = "Riesgo académico";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);
    
    $record->nombre="economico";
    $record->descripcion = "Riesgo económico";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);
    
    $record->nombre="vida_universitaria";
    $record->descripcion = "Riesgo vida universitaria";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);
    
    $record->nombre="geografico";
    $record->descripcion = "Riesgo geográfico";
    $result = $DB->insert_record('talentospilos_riesgos_ases', $record, false);
    print_r($result);

    //motivos
    // bajo rendimiento
    // retiro voluntario
    // calamidad domestica
    // enfermedad
    // traslado universidad
    // situacion economica
    // insatisfaccion con el programa
    // falta de adaptacion a la vida universitaria

    $array_motivos = array('Bajo rendimiento','Retiro voluntario','Calamidad domestica','Enfermedad','Traslado de universidad','Situacion economica','Insatisfacción con el programa','Falta de adaptación a la vida universitaria');
    // print_r(count($array_motivos));
    for($riesgo=0;$riesgos<count($array_motivos);$riesgo++)
    {
        //print_r($riesgo);
        $result = $DB->insert_record('talentospilos_motivos', array('decripcion'=>$array_motivos[$riesgo]), false);
        print_r($result);
    }
    
    // $array_numdoc = array('98092467996','98103153174','98062166436','98032257895','98110757620','98063068292','98022853953','98102621484','97072314615','97112102837','98102413580','98111359253','98102272560','98071155390','98101066045');
    // $array_username = array('1673499','1674358','1673610','1673715','1673508','1673676','1674003','1674411','1673604','1673270','1673713','1674298','1674544','1673680','1674309');
    // $array_id_pilos = array();
    // $array_id_user = array();
    
    // for($i = 0; $i < count($array_numdoc); $i++){
    //     $sql_query = "SELECT id FROM {talentospilos_usuario} WHERE num_doc_ini = '$array_numdoc[$i]'";
    //     $result = $DB->get_record_sql($sql_query);
    //     array_push($array_id_pilos, $result->id);
        
    //     $sql_query = "SELECT id FROM {user} WHERE username LIKE '$array_username[$i]%'";
    //     $result = $DB->get_record_sql($sql_query);
    //     array_push($array_id_user, $result->id);
    // }
    
    // print_r($array_id_pilos);
    // print_r($array_id_user);
    
    // for($j = 0; $j < count($array_id_pilos); $j++){
    //     $sql_query = "UPDATE {user_info_data} SET data = $array_id_pilos[$j] WHERE userid = '$array_id_user[$j]' AND fieldid = 2";
    //     $result = $DB->execute($sql_query);
    //     print_r($result);
    // }

    // $sql_query = "SELECT id FROM {talentospilos_usuario} WHERE num_doc = '98091869098'";
    // $id_pilos = $DB->get_record_sql($sql_query);

    // $sql_query = "SELECT id FROM {user} WHERE username LIKE '1674632%'";
    // $id_moodle = $DB->get_record_sql($sql_query);

    // $sql_query = "UPDATE {user_info_data} SET data = '$id_pilos->id' WHERE userid = $id_moodle->id AND fieldid = 2";
    // $result = $DB->execute($sql_query);
    
    // $record->id_rol = 6;
    // $record->id_permiso = 3;
    // $record->id_funcionalidad = 8;
    // $result = $DB->insert_record('talentospilos_permisos_rol', $record, false);
    
    // print_r($result);
    
    // $record->id_rol = 6;
    // $record->id_permiso = 1;
    // $record->id_funcionalidad = 8;
    // $result =  $DB->insert_record('talentospilos_permisos_rol', $record, false);
    
    // print_r($result);
    
    // $record->id_rol = 6;
    // $record->id_permiso = 2;
    // $record->id_funcionalidad = 8;
    // $result =  $DB->insert_record('talentospilos_permisos_rol', $record, false);
    
    // print_r($result);

    // $record->id_rol = 6;
    // $record->id_permiso = 4;
    // $record->id_funcionalidad = 8;
    // $result = $DB->insert_record('talentospilos_permisos_rol', $record, false);

    // print_r($result);
    
//   $firstsemester = getIdFirstSemester(256);
//         $lastsemestre = getIdLastSemester(256);
        
//     print_r('firstsemester: '.$firstsemester.'<br>lastsemester: '.$lastsemestre);