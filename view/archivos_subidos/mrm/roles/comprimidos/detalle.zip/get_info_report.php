<?php
require('query.php');

global $USER;

if(isset($_POST['type'])&&$_POST['type']=="id") 
 {
  $retorno = getNameRol(1049,534);
    echo(json_encode($retorno));
}

if(isset($_POST['type'])&&$_POST['type']=="info_monitor"&&$_POST['hasdata']=="no") 
 {
    $retorno = get_seguimientos_monitor(1049);
    echo (json_encode($retorno));
}

if(isset($_POST['type'])&&$_POST['type']=="info_monitor"&&$_POST['hasdata']!="no") 
 {
    $retorno = get_seguimientos_monitor($_POST['hasdata']);
    echo (json_encode($retorno));
}

if(isset($_POST['type'])&&$_POST['type']=="info_practicante") 
 {
    $retorno = get_monitores_practicante(1112);
    echo (json_encode($retorno));
}

if(isset($_POST['value'])&&isset($_POST['type'])&&$_POST['type']=="fecha") 
 {
  $time=$_POST['value'];
  echo seg2hum($time);
  
}

function seg2hum($segundos){ 
$mes = date(n, $segundos); 
$mesArray = array(1 => "Enero", 2 => "Febrero", 3 => "Marzo", 4 => "Abril", 5 => "Mayo", 6 => "Junio", 7 => "Julio", 8 => "Agosto", 9 => "Septiembre", 10 => "Octubre", 11 => "Noviembre", 12 => "Diciembre" ); 
echo date(d, $segundos)."/".$mesArray[$mes]."/".date(Y, $segundos); 
}

