<?php
require_once(dirname(__FILE__). '/../../../config.php');
require('query.php');
global $DB;

$sql_query = "SELECT seguimiento.id,
                     segEstudiante.id_estudiante, 
                     segEstudiante.id_seguimiento, 
                     seguimiento.familiar_riesgo, 
                     seguimiento.academico_riesgo,
                     seguimiento.economico_riesgo,
                     seguimiento.vida_uni_riesgo, 
                     seguimiento.individual_riesgo 
              FROM {talentospilos_seguimiento} AS seguimiento INNER JOIN 
                   {talentospilos_seg_estudiante} AS segEstudiante ON seguimiento.id = segEstudiante.id_seguimiento
              ORDER BY seguimiento.id";

$array_risk = $DB->get_records_sql($sql_query);

foreach($array_risk as $student){
    
    $sql_query = "SELECT COUNT(id) FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante.";";
    $exists_user = $DB->get_record_sql($sql_query);
    
    if($exists_user->count == 0){
        
        $record->id_usuario = $student->id_estudiante;
        $record->id_riesgo = 1;
        $record->calificacion_riesgo = $student->individual_riesgo;
        $DB->insert_record('talentospilos_riesg_usuario', $record, false);

        $record->id_usuario = $student->id_estudiante;
        $record->id_riesgo = 2;
        $record->calificacion_riesgo = $student->familiar_riesgo;
        $DB->insert_record('talentospilos_riesg_usuario', $record, false);
        
        $record->id_usuario = $student->id_estudiante;
        $record->id_riesgo = 3;
        $record->calificacion_riesgo = $student->academico_riesgo;
        $DB->insert_record('talentospilos_riesg_usuario', $record, false);

        $record->id_usuario = $student->id_estudiante;
        $record->id_riesgo = 4;
        $record->calificacion_riesgo = $student->economico_riesgo;
        $DB->insert_record('talentospilos_riesg_usuario', $record, false);
        
        $record->id_usuario = $student->id_estudiante;
        $record->id_riesgo = 5;
        $record->calificacion_riesgo = $student->vida_uni_riesgo;
        $DB->insert_record('talentospilos_riesg_usuario', $record, false);
        
    }else{
        
        // Riesgo individual
        $sql_query = "SELECT * FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante." AND id_riesgo= 1;";
        $result = $DB->get_record_sql($sql_query);

        if($result->calificacion_riesgo != $student->individual_riesgo && $student->individual_riesgo > 0){
            
            $dataobject->id = $result->id;
            $dataobject->calificacion_riesgo = $student->individual_riesgo;
            $DB->update_record('talentospilos_riesg_usuario', $dataobject, false);
        }
        
        // Riesgo familiar
        $sql_query = "SELECT * FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante." AND id_riesgo= 2;";
        $result = $DB->get_record_sql($sql_query);

        if($result->calificacion_riesgo != $student->familiar_riesgo && $student->familiar_riesgo > 0){
            
            $dataobject->id = $result->id;
            $dataobject->calificacion_riesgo = $student->familiar_riesgo;
            $DB->update_record('talentospilos_riesg_usuario', $dataobject, false);
        }

        // Riesgo academico
        $sql_query = "SELECT * FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante." AND id_riesgo= 3;";
        $result = $DB->get_record_sql($sql_query);

        if($result->calificacion_riesgo != $student->academico_riesgo && $student->academico_riesgo > 0){
            
            $dataobject->id = $result->id;
            $dataobject->calificacion_riesgo = $student->academico_riesgo;
            $DB->update_record('talentospilos_riesg_usuario', $dataobject, false);
        }
        
        
        // Riesgo economico
        $sql_query = "SELECT * FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante." AND id_riesgo= 4;";
        $result = $DB->get_record_sql($sql_query);

        if($result->calificacion_riesgo != $student->economico_riesgo && $student->economico_riesgo > 0){
            
            $dataobject->id = $result->id;
            $dataobject->calificacion_riesgo = $student->economico_riesgo;
            $DB->update_record('talentospilos_riesg_usuario', $dataobject, false);
        }

        // Riesgo vida universitaria
        $sql_query = "SELECT * FROM {talentospilos_riesg_usuario} WHERE id_usuario =".$student->id_estudiante." AND id_riesgo= 5;";
        $result = $DB->get_record_sql($sql_query);

        if($result->calificacion_riesgo != $student->vida_uni_riesgo && $student->vida_uni_riesgo > 0){
            
            $dataobject->id = $result->id;
            $dataobject->calificacion_riesgo = $student->vida_uni_riesgo;
            $DB->update_record('talentospilos_riesg_usuario', $dataobject, false);
        }

    }
}



